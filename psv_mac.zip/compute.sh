#!/bin/bash

push_swap=.././push_swap

"$push_swap" $1 > ps_out
