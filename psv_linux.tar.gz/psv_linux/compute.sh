#!/bin/bash

cd ../host_ps/ && ./push_swap $1 > ps_out
